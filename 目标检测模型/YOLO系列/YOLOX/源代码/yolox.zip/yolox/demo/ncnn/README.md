# YOLOX-ncnn

Compile files of YOLOX object detection base on [ncnn](https://github.com/Tencent/ncnn).  
YOLOX is included in ncnn now, you could also try building from ncnn, it's better.

## Acknowledgement

* [ncnn](https://github.com/Tencent/ncnn)
