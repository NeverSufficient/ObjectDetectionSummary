Prototxt files that define models and solvers.

Three models are defined, with some variations of each to support experiments
in the paper.
 - Caffenet (model **S**)
 - VGG_CNN_M_1024 (model **M**)
 - VGG16 (model **L**)
