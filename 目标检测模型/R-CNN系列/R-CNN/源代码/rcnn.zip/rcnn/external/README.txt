rcnn/external/caffe should be a symlink to where you installed caffe

liblinear downloaded from http://www.csie.ntu.edu.tw/~cjlin/liblinear/
