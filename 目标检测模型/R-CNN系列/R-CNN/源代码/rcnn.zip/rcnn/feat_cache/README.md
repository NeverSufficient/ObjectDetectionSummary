## Feature cache

R-CNN stores cached features in: `rcnn/feat_cache/[cache_name]`. I typically create symlinks from `[cache_name]` to fast, local storage.
