# FCOS Core
Note that `fcos_core` corresponds to `maskrcnn_benchmark` in the original maskrcnn_benchmark repository. \
We changed the name to avoid conflicts with the original maskrcnn-benchmark installation.

The core code of FCOS detector is located under [modeling/rpn/fcos](modeling/rpn/fcos).
